"use client";

import { type FormEvent, type ReactNode, useEffect, useRef, useState } from "react";

function hideUnavailableImage(image: HTMLImageElement) {
  image.hidden = true;

  const slide = image.closest<HTMLElement>(".slide");
  if (!slide) return;

  const availableImages = Array.from(slide.querySelectorAll("img")).filter(
    (slideImage) => !slideImage.hidden,
  );
  slide.classList.toggle("slide--single-image", availableImages.length === 1);

  if (availableImages.length === 0) {
    slide.hidden = true;
    const remainingSlides = Array.from(
      slide.parentElement?.querySelectorAll<HTMLElement>(".slide") ?? [],
    ).filter((candidate) => !candidate.hidden);

    if (!remainingSlides.some((candidate) => getComputedStyle(candidate).opacity === "1")) {
      remainingSlides[0]?.style.setProperty("opacity", "1");
    }
  }
}

export default function LegacyInteractions({
  children,
  contactForm = false,
}: {
  children: ReactNode;
  contactForm?: boolean;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [formMessage, setFormMessage] = useState("");

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const menuToggle = container.querySelector<HTMLElement>(".menu-toggle");
    const menu = container.querySelector<HTMLElement>("#nav-menu");
    const toggleMenu = () => {
      const isOpen = menu?.classList.toggle("show") ?? false;
      menuToggle?.setAttribute("aria-expanded", String(isOpen));
    };
    const handleMenuKey = (event: KeyboardEvent) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        toggleMenu();
      }
    };
    const handleClick = (event: MouseEvent) => {
      const target = event.target;
      if (!(target instanceof Element)) return;

      if (target.closest(".menu-toggle")) {
        toggleMenu();
        return;
      }

      if (target.closest(".print-download button")) {
        window.print();
        return;
      }

      const arrow = target.closest(".arrow-left, .arrow-right");
      if (arrow) {
        const slides = Array.from(container.querySelectorAll<HTMLElement>(".slide")).filter(
          (slide) => !slide.hidden,
        );
        if (slides.length === 0) return;

        const activeIndex = slides.findIndex((slide) => slide.style.opacity === "1");
        const currentIndex = activeIndex < 0 ? 0 : activeIndex;
        const nextIndex = arrow.classList.contains("arrow-right")
          ? (currentIndex + 1) % slides.length
          : (currentIndex - 1 + slides.length) % slides.length;

        slides.forEach((slide, index) => {
          slide.style.opacity = index === nextIndex ? "1" : "0";
          slide.setAttribute("aria-hidden", String(index !== nextIndex));
        });
        return;
      }
    };
    const handleChange = (event: Event) => {
      const target = event.target;
      if (!(target instanceof HTMLSelectElement) ||
          !target.matches(".notice-filter select")) return;

      container.querySelectorAll<HTMLElement>(".notice-item").forEach((item) => {
        item.hidden =
          target.value !== "all" && item.dataset.category !== target.value;
      });
    };
    const handleInput = (event: Event) => {
      const target = event.target;
      if (!(target instanceof HTMLInputElement) || target.id !== "searchBox") return;
      const search = target.value.trim().toLocaleLowerCase();

      container.querySelectorAll<HTMLTableRowElement>("table tbody tr").forEach((row) => {
        const isHeading = row.querySelector("th") !== null;
        const matches = isHeading || row.textContent?.toLocaleLowerCase().includes(search);
        row.hidden = !matches;
      });
    };
    const handleImageError = (event: Event) => {
      if (event.target instanceof HTMLImageElement) {
        hideUnavailableImage(event.target);
      }
    };

    if (menuToggle) {
      menuToggle.tabIndex = 0;
      menuToggle.setAttribute("role", "button");
      menuToggle.setAttribute("aria-expanded", "false");
      menuToggle.setAttribute("aria-label", "Toggle navigation");
      menuToggle.addEventListener("keydown", handleMenuKey);
    }

    container.addEventListener("click", handleClick);
    container.addEventListener("change", handleChange);
    container.addEventListener("input", handleInput);
    container.addEventListener("error", handleImageError, true);
    container.querySelectorAll("img").forEach((image) => {
      if (image.complete && image.naturalWidth === 0) {
        hideUnavailableImage(image);
      }
    });

    return () => {
      menuToggle?.removeEventListener("keydown", handleMenuKey);
      container.removeEventListener("click", handleClick);
      container.removeEventListener("change", handleChange);
      container.removeEventListener("input", handleInput);
      container.removeEventListener("error", handleImageError, true);
    };
  }, []);

  async function submitContactForm(event: FormEvent<HTMLDivElement>) {
    if (!contactForm || !(event.target instanceof HTMLFormElement)) return;

    const form = event.target;
    if (!form.querySelector('[name="name"]') ||
        !form.querySelector('[name="email"]') ||
        !form.querySelector('[name="message"]')) {
      return;
    }

    event.preventDefault();
    setFormMessage("Sending your message...");

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(Object.fromEntries(new FormData(form))),
      });
      const result = (await response.json()) as { error?: string; message?: string };

      if (!response.ok) {
        setFormMessage(result.error ?? "Your message could not be sent. Please try again.");
        return;
      }

      form.reset();
      setFormMessage(result.message ?? "Your message has been sent.");
    } catch {
      setFormMessage("Unable to reach the server. Please try again.");
    }
  }

  return (
    <div
      className="legacy-interactions"
      ref={containerRef}
      onSubmitCapture={submitContactForm}
    >
      {children}
      {contactForm && (
        <p className="form-status" role="status" aria-live="polite">
          {formMessage}
        </p>
      )}
    </div>
  );
}
