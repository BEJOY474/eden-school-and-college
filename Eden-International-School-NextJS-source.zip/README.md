# Eden International School & College

The Next.js app serves each page at its own route using the original HTML page sources in `legacy-pages/`. Website images, the admission form, and other original media are kept in `public/assets/`; the pages' existing copy and supplied images are preserved.

## Routes

- `/` — Home
- `/about` — About
- `/academics` — Academics
- `/admission` — Admission
- `/contact` — Contacts
- `/faculty` — Faculty
- `/gallery` — Gallery
- `/results` — Results
- `/staff` — All Teachers

Each route has a separate page file under `app/`. Shared page rendering and legacy navigation behavior live in `components/`. The project root contains only the app, shared code, source pages, public assets, and the configuration needed to run it.

## Run locally

1. Install Node.js 20 or newer.
2. Install project dependencies with `npm install`.
3. Copy `.env.example` to `.env.local` and set `DATABASE_URL` to your MySQL connection string.
4. Run `database/schema.sql` in MySQL to create the database and contact-message table.
5. Start the development server with `npm run dev`.

The contact form stores messages in MySQL. The database table is not created automatically; apply the supplied SQL schema before using the form. Never commit `.env.local` or production database credentials.

Use `npm run typecheck` to check TypeScript and `npm run build` to create a production build.
