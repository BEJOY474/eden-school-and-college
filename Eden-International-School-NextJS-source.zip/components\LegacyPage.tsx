import { readFileSync } from "node:fs";
import path from "node:path";
import LegacyInteractions from "./LegacyInteractions";

const sourceFiles = {
  home: "index.html",
  about: "About.html",
  academics: "Academics.html",
  admission: "Admission.html",
  contact: "Contacts.html",
  faculty: "Faculty.html",
  gallery: "Gallery.html",
  results: "Result.html",
  staff: "employ.html",
} as const;

export type LegacyPageName = keyof typeof sourceFiles;

const routeByLegacyFile: Record<string, string> = {
  "index.html": "/",
  "About.html": "/about",
  "Faculty.html": "/faculty",
  "Admission.html": "/admission",
  "Academics.html": "/academics",
  "Result.html": "/results",
  "Gallery.html": "/gallery",
  "Contacts.html": "/contact",
  "employ.html": "/staff",
  "gallery.html": "/gallery",
  "faculty.html": "/faculty",
};

function getPageMarkup(page: LegacyPageName) {
  const filePath = path.join(process.cwd(), "legacy-pages", sourceFiles[page]);
  const source = readFileSync(filePath, "utf8");
  const body = source.match(/<body\b[^>]*>([\s\S]*?)<\/body>/i)?.[1];

  if (!body) {
    throw new Error(`The source page "${sourceFiles[page]}" has no body element.`);
  }

  const cleanedBody = body
    .replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi, "")
    .replace(/\s+on[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, "")
    .replace(
      /\b(href|src)\s*=\s*(["'])([^"']+)\2/gi,
      (attribute, name: string, quote: string, value: string) => {
        const normalized = value.trim();
        const legacyRoute = routeByLegacyFile[normalized];

        if (legacyRoute) {
          return `${name}=${quote}${legacyRoute}${quote}`;
        }

        if (/^file:\/\/\/.*Admission(?:%20| )Form\.pdf$/i.test(normalized)) {
          return `${name}=${quote}/assets/Admission%20Form.pdf${quote}`;
        }

        if (
          /^(?:https?:|mailto:|tel:|data:|#|\/)/i.test(normalized) ||
          name.toLowerCase() !== "src" && !/\.(?:pdf)$/i.test(normalized)
        ) {
          return attribute;
        }

        return `${name}=${quote}/assets/${encodeURI(normalized)}${quote}`;
      },
    );
  const navigationEnd = cleanedBody.toLowerCase().lastIndexOf("</nav>");

  if (navigationEnd === -1) {
    throw new Error(`The source page "${sourceFiles[page]}" has no navigation element.`);
  }

  const contentStart = navigationEnd + "</nav>".length;
  return `${cleanedBody.slice(0, contentStart)}<div class="page-content">${cleanedBody.slice(contentStart)}</div>`;
}

export default function LegacyPage({
  page,
}: {
  page: LegacyPageName;
}) {
  const markup = getPageMarkup(page);

  return (
    <LegacyInteractions contactForm={page === "contact"}>
      <main
        className={`legacy-page legacy-page--${page}`}
        dangerouslySetInnerHTML={{ __html: markup }}
      />
    </LegacyInteractions>
  );
}
